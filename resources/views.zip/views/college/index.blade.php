@extends('layouts.college_app')
@section('content')
<div class="page-content main-index h-100">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="page-title-box d-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0 font-size-18">Dashboard</h4>
                </div>
            </div>

        </div>

    </div> 
</div>
@endsection